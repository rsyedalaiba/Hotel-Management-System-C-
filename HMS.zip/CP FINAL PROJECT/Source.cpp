#include<iostream>
#include<string>
#include <windows.h>
#include <stdlib.h>
#include <fstream>

using namespace std;

struct Hotel {
	
	int Total;
	
	
}H;

void file (int a){
	
    
	fstream Leddger;
	Leddger.open("Leddger.txt", ios::out);
	if (!Leddger) {
		cout << "File not created!";
	}
	else {
		cout << "File created successfully!";
		Leddger.close(); 
		ofstream Leddger;
		Leddger.open ("Leddger.txt",ios::out);

        Leddger <<a <<endl; 
    cout<<"\n Leddger Maintained\n\n";
    

    Leddger.close();
    Leddger.close();
	}
}

int Total(int a)
{
	int cal=0,t;
	switch (a)
	{
	case 1:
	{
		cal = cal + 200;
		break;
	}
	case 2:
	{
		cal = cal + 250;
		break;
	}
	case 3:
	{
		cal = cal + 300;
		break;
	}
	case 4:
	{
		cal = cal + 650;
		break;
	}
	case 5:
	{
		cal = cal + 200;
		break;
	}
	default:
		break;
	}
	t = cal;

	return t;
	
}

void Resturant(Hotel H) {
	system("Color 74");
	system("CLS");
	
	int Item,z,cal=0;
	char T,Pay;
	cout << "\t\t\tWelcome to MARCOPOLO RESTURANT - Pearl Continental\n\n";
	cout << "\n\n\t\t\tFollowing is the menu\n\n\t1- Nuggets\t\t200\n\t2- Buffalo wings\t250\n\t3- Salad\t\t300\n\t4- Jalapeno Zinger\t650\n\t5- Coffee\t\t200\n";
	do
	{
		cout << "Enter the number of the item you want\n->";
		cin >> Item;
		z=Total(Item);
		cal = cal + z;
		cout << "You want to add another Item?\n->";
		cin >> T;
	} while (T=='y');

	cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
	cin >> Pay;

	if (Pay == 'd')
	{
		cout << "Extra 200 will be charge on Card\n";
		cal = cal + 200;
		cout << "\n\nYour totall Bill is = " << cal << "\n";
		file(cal);	
		cout << "PAID!\n\nWe hope you Loved the meal, Thankyou\n";
	}
	else if (Pay == 'c')
	{
		cout << "\n\nYour totall Bill is = " << cal << "\n";
		file(cal);

		cout << "\n\t\t\tPAID!\n\nWe hope you Loved the meal, Thankyou\n";
	}
	return;
}

void EventCatringFinalReciept(int a, int b)
{
	system("Color 74");
	system("CLS");
	switch (b)
	{
		int cal;
		char Pay;
	case 1:
	{
		cal = a * 250;
		cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
		cin >> Pay;

		if (Pay == 'd')
		{
			cout << "Extra 200 will be charge on Card\n";
			cal = cal + 200;
			cout << "Your totall Bill is = " << cal << "\n";
			file(cal);

			cout << "PAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		else if (Pay == 'c')
		{
			cout << "Your totall Bill is = " << cal << "\n";
			file(cal);
			
			cout << "\n\t\t\tPAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		break;
	}
	case 2:
	{
		cal = a * 350;
		cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
		cin >> Pay;

		if (Pay == 'd')
		{
			cout << "Extra 200 will be charge on Card\n";
			cal = cal + 200;
			cout << "Your totall Bill is = " << cal << "\n";
			file(cal);

			cout << "PAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		else if (Pay == 'c')
		{
			cout << "Your totall Bill is = " << cal << "\n";
			file(cal);
			
			cout << "\n\t\t\tPAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		break;
	}
	case 3:
	{
		cal = a * 450;
		cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
		cin >> Pay;

		if (Pay == 'd')
		{
			cout << "Extra 200 will be charge on Card\n";
			cal = cal + 200;
			cout << "Your totall Bill is = " << cal << "\n";
			file(cal);

			cout << "PAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		else if (Pay == 'c')
		{
			cout << "Your totall Bill is = " << cal << "\n";
			file(cal);
			
			cout << "\n\t\t\tPAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		break;
	}
	default:
		break;
	}
}

void RoomFinalReceipt(int a, int b) {
	system("Color 74");
	system("CLS");
	switch (b)
	{
		int Cal;
		char Pay;
	case 1:
	{
		Cal = 20000 * a;
		cout << "Your total Bill for the stay is = "<<Cal<<"\n";
		cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
		cin >> Pay;

		if (Pay == 'd')
		{
			cout << "Extra 200 will be charge on Card\n";
			Cal = Cal + 200;
			cout << "Your totall Bill is = " << Cal << "\n";
			file(Cal);

			cout << "PAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		else if (Pay == 'c')
		{
			cout << "Your totall Bill is = " << Cal << "\n";
			file(Cal);

			cout << "\n\t\t\tPAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		break;
	}
	case 2:
	{
		Cal = 25000 * a;
		cout << "Your total Bill for the stay is = " << Cal << "\n";
		cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
		cin >> Pay;

		if (Pay == 'd')
		{
			cout << "Extra 200 will be charge on Card\n";
			Cal = Cal + 200;
			cout << "Your totall Bill is = " << Cal << "\n";
			file(Cal);

			cout << "PAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		else if (Pay == 'c')
		{
			cout << "Your totall Bill is = " << Cal << "\n";
			file(Cal);

			cout << "\n\t\t\tPAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		break;
	}
	case 3:
	{
		Cal = 35000 * a;
		cout << "Your total Bill for the stay is = " << Cal << "\n";
		cout << "You want to pay via Debit/Credit card OR via Cash?\nEnter ( d ) for card OR ( c ) for Cash\n->";
		cin >> Pay;

		if (Pay == 'd')
		{
			cout << "Extra 200 will be charge on Card\n";
			Cal = Cal + 200;
			cout << "Your totall Bill is = " << Cal << "\n";
			file(Cal);

			cout << "PAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		else if (Pay == 'c')
		{
			cout << "Your totall Bill is = " << Cal << "\n";
			file(Cal);

			cout << "\n\t\t\tPAID!\n\nWe hope you will like the stay at Pearl Continental, Thankyou\n";
		}
		break;
	}
	default:
		break;
	}

}
void RoomPrice(int a) {
	system("Color 74");
	system("CLS");
	switch (a)
	{
		int NoOfRooms;
	case 1:
	{
		
		cout << "The Price of Deluxe room is = 20,000 pkr/night\n";
		cout << "How many Rooms do you want?\n->";
		cin >> NoOfRooms;
		RoomFinalReceipt(NoOfRooms,a);

		break;
	}
	case 2:
	{
		cout << "The Price of Deluxe Plus room is = 25,000 pkr/night\n";
		cout << "How many Rooms do you want?\n->";
		cin >> NoOfRooms;
		RoomFinalReceipt(NoOfRooms,a);
		break;
	}
	case 3:
	{
		cout << "The Price of Executive room is = 35,000 pkr/night\n";
		cout << "How many Rooms do you want?\n->";
		cin >> NoOfRooms;
		RoomFinalReceipt(NoOfRooms,a);
		break;
	}
	default:
		break;
	}

}

void HotelRoom()
{
	int c, d;
	char f,g;
	int RoomDate[6] = { 19, 10, 8, 17, 9, 15 };
	system("Color 74");
	cout << "\t\tPearl-Continental Hotel Karachi is a part of the most significant chain\n\tGuests can choose from a variety of rooms and suites to enjoy their stay at the five-star hotel\n\n";
	cout << "Please select the catagory of the room\n";
	
	cout << "1- Deluxe\n2- Deluxe Plus\n3- Executive\n->";
	cin >> c;

	
	switch (c)
	{
		
	case 1:
	{
		do
		{
			cout << "Please Enter the Booking date\n->";
			cin >> d;
		
			for (int i = 0; i < 6; i++)
			{
				if (RoomDate[i] == d)
				{
					cout << "Your Deluxe room is available on your required date\n";
					RoomPrice(c);
					return;
				}
				else {
					cout << "\n";
				}
			}
				cout << "Sorry! No Deulxe room is available on your required date\n";
				cout << "Deluxe room is available on the following dates\n\n19, 10, 8, 17, 9, 15\n";
				cout << "You want to change the catagory of the room?\n\n->";
				cin >> f;

				if (f=='y')
				{
					HotelRoom();
				}
				else if(f=='n') {
					cout << "\n";
				}
			
			cout << "Do you want to change the date?\n->";
			cin >> g;
		} while (g=='y');
		system("CLS");
		cout << "\t\t\tThanyou for choosing Pearl Continental, We will be happy to serve you in future\n\n\n";
		break;
	}

	case 2:
	{
		do
		{
			cout << "Please Enter the Booking date\n->";
			cin >> d;

			for (int i = 0; i < 6; i++)
			{
				if (RoomDate[i] == d)
				{
					cout << "Your Deluxe room is available on your required date\n";
					RoomPrice(c);
					return;
				}
				else {
					cout << "\n";
				}
			}
			cout << "Sorry! No Deulxe Plus room is available on your required date\n";
			cout << "Deluxe room is available on the following dates\n\n19, 10, 8, 17, 9, 15\n";
			cout << "You want to change the catagory of the room?\n\n->";
			cin >> f;

			if (f == 'y')
			{
				HotelRoom();
			}
			else if (f == 'n') {
				cout << "\n";
			}

			cout << "Do you want to change the date?\n->";
			cin >> g;
		} while (g == 'y');
		system("CLS");
		cout << "\t\t\tThanyou for choosing Pearl Continental, We will be happy to serve you in future\n\n\n";
		break;
	}

	case 3:
	{
		do
		{
			cout << "Please Enter the Booking date\n->";
			cin >> d;

			for (int i = 0; i < 6; i++)
			{
				if (RoomDate[i] == d)
				{
					cout << "Your Deluxe room is available on your required date\n";
					RoomPrice(c);
					return;
				}
				else {
					cout << "\n";
				}
			}
			cout << "Sorry! No Executive room is available on your required date\n";
			cout << "Deluxe room is available on the following dates\n\n19, 10, 8, 17, 9, 15\n";
			cout << "You want to change the catagory of the room?\n\n->";
			cin >> f;

			if (f == 'y')
			{
				HotelRoom();
			}
			else if (f == 'n') {
				cout << "\n";
			}

			cout << "Do you want to change the date?\n->";
			cin >> g;
		} while (g == 'y');
		system("CLS");
		cout << "\t\t\tThanyou for choosing Pearl Continental, We will be happy to serve you in future\n\n\n";
		break;
	}

	
	default:
		break;
	}


	
	
}

void EventCatring()
{
	
	system("Color 74");
	system("CLS");
	int VenueArea, NoOfPersons;
	char m;
	cout << "\t\t\tBRINGING PEOPLE TOGETHER\n\n";
	cout << "Select the Venue from the following list\n\n1- Signature\n2- Daimond\n3- Gold\n->";
	cin >> VenueArea;

	switch (VenueArea)
	{
	case 1:
	{
		system("CLS"); 
		cout << "\tSignature hall has a capacity of 400 people\n\tHaving a WOW frames and decent temperature\n";
		cout << "\tPer head = 250\n\tMinimum of 100 people\n\tIncluding 20 tasty Dishes\n";
		
		do
		{
			cout << "\tEnter the number of persons =";
			cin >> NoOfPersons;
			cout << "\n\n";

			if (NoOfPersons < 100)
			{
				cout << "Sorry Number of persons should be greater than 100\n";
			}
			else if (NoOfPersons >= 100)
			{
				EventCatringFinalReciept(NoOfPersons, VenueArea);
				return;
			}
			cout << "\nYou want to enter No of persons again?\n";
			cin >> m;
		} while (m == 'y');
		break;
	}
	case 2:
	{
		system("CLS");
		cout << "\tDaimond hall has a capacity of 500 people\n\tHaving a WOW frames and decent temperature\n";
		cout << "\tPer head = 350\n\tMinimum of 100 people\n\tIncluding 20 tasty Dishes\n";
		do
		{
			cout << "\tEnter the number of persons =";
			cin >> NoOfPersons;
			cout << "\n\n";

			if (NoOfPersons < 100)
			{
				cout << "Sorry Number of persons should be greater than 100\n";
			}
			else if (NoOfPersons >= 100)
			{
				EventCatringFinalReciept(NoOfPersons, VenueArea);
				return;
			}
			cout << "\nYou want to enter No of persons again?\n";
			cin >> m;
		} while (m == 'y');
		break;
	}
	case 3:
	{
		system("CLS");
		cout << "\tGold hall has a capacity of 600 people\n\tHaving a WOW frames and decent temperature\n";
		cout << "\tPer head = 450\n\tMinimum of 100 people\n\tIncluding 20 tasty Dishes\n";
		do
		{
			cout << "\tEnter the number of persons =";
			cin >> NoOfPersons;
			cout << "\n\n";

			if (NoOfPersons < 100)
			{
				cout << "Sorry Number of persons should be greater than 100\n";
			}
			else if (NoOfPersons >= 100)
			{
				EventCatringFinalReciept(NoOfPersons, VenueArea);
				return;
			}
			cout << "\nYou want to enter No of persons again?\n";
			cin >> m;
		} while (m == 'y');
		break;
	}
	default:
		break;
	}
}

int main()
{
	Hotel H;
	


	system("Color 0A");
	int b;
	cout << "\t** WELCOME TO Pearl Continental HOTEL MANAGMENT SYSTEM ** \n\n";
	
		
		cout << "Select the purpose of choosing Pearl Continental\n";
		cout << "1- Hotel (Room Booking)\n2- Event/Catring services\n3- Resturant (Dine-In)\n->";
		cin >> b;

		switch (b)
		{
		case 1:
			{
				system("CLS");
				HotelRoom();
				break;
			}
		case 2:
		{
			system("CLS");
			EventCatring();
			
			break;
		}
		case 3:
		{
			system("CLS");
			Resturant(H);

			break;
		}
		default:
			break;
		}
		
	system("pause");
	}
	  

